# This line will allow shorter imports
from medium_multiply.multiplication import Multiplication
